﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.Entity;

namespace EFCodeFirstWithDatabase.Models
{
    //
    // POCO Model Classes
    //
    // Note: These could be in a separate class library project. I've
    // kept them in the same project purely to keep the sample simple.

    public class Product
    {
        public int      ProductID    { get; set; }
        public string   ProductName  { get; set; }
        public int?     CategoryID   { get; set; }
        public Decimal? UnitPrice    { get; set; }
        public bool     Discontinued { get; set; }

        public virtual Category Category { get; set; }
    }

    public class Category
    {
        public int      CategoryID   { get; set; }
        public string   CategoryName { get; set; }
        public string   Description  { get; set; }
        public byte[]   Picture      { get; set; }

        public virtual  ICollection<Product> Products { get; set; }
    }

    //
    // Northwind EF Code First Context Class
    //
    // Note: This class could be in a separate class library project. It
    // could even be in a separate project from the above model classes.
    // This would allow you to separate your model and persistence logic into
    // two separate projects.

    public class Northwind : DbContext
    {
        public DbSet<Product>   Products   { get; set; }
        public DbSet<Category>  Categories { get; set; }
    }
}