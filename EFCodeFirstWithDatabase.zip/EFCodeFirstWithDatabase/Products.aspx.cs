﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EFCodeFirstWithDatabase.Models;

namespace EFCodeFirstWithDatabase
{
    public partial class Products : System.Web.UI.Page
    {
        void Page_Load()
        {            
            Northwind northwind = new Northwind();

            var products = from p in northwind.Products
                           where p.Discontinued == false
                           select p;

            GridView1.DataSource = products;
            GridView1.DataBind();
        }
    }
}